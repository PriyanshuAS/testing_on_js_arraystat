# Rewrite using .map() function instead of using closure

## Use array_stat.js for code logic
## Use array_stat.spec.js for testing logic

'''
npm init -y
npm install --save-dev jasmine
npx jasmine init
'''

## add .spec.js path to package.json in the test field